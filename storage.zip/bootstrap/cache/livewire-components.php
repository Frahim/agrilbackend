<?php return array (
  'admin.brand.index' => 'App\\Http\\Livewire\\Admin\\Brand\\Index',
  'admin.category.index' => 'App\\Http\\Livewire\\Admin\\Category\\Index',
);