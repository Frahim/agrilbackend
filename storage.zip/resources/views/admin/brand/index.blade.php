@extends ('layouts.admin')

@section('content')
<div>
    <livewire:admin.brand.index />
</div>
@endsection
