

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between py-3">
                <h3 class="mb-0">All Employs</h3>
                <a href="<?php echo e(url('admin/employ/create')); ?>" class="btn btn-primary text-white float-end">Add Employ</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table  table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Name</th>                               
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Mobile</th>
                                <th scope="col">Bio</th>
                                <th scope="col">Designeation</th>  
                                <th scope="col">Department</th> 
                                <th scope="col">brand_id</th>  
                                <th scope="col">picture</th> 
                                <th scope="col">Seting</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>                                    
                                    <td><?php echo e($employ->name); ?> <br/><small>ID:<?php echo e($employ->id); ?></small></td>                                    
                                    <td><?php echo e($employ->email); ?></td>
                                    <td><?php echo e($employ->phonenumber); ?></td>                                   
                                    <td><?php echo e($employ->mobile); ?></td>
                                    <td><?php echo e($employ->bio); ?></td>
                                    <td><?php echo e($employ->designeation); ?></td>
                                    <td><?php echo e($employ->department); ?></td>
                                    <td><?php echo e($employ->brand_id); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('/uploads/employ/' . $employ->picture)); ?>" width="60px"
                                            height="60px" />
                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('admin/employ/' . $employ->id . '/edit')); ?>"
                                            class="btn btn-success">Edit</a>                                       
                                            <form action="<?php echo e(url('admin/employ/' . $employ->id . '')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <input type="submit" class="btn btn-danger" value="Delete" />
                                            </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views/admin/employ/index.blade.php ENDPATH**/ ?>