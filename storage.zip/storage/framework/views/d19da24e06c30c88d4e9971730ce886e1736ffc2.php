

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(session('message')): ?>
            <div class="col-md-10 alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center py-2">
                    <h3 class="m-0 align-middle">Banners</h3>
                    <a href="<?php echo e(url('admin/banner/create')); ?>" class="btn btn-primary btn-sm float-end">Add Banner</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table  table-striped">
                            <thead>
                                <tr>                                   
                                    <th scope="col">Name</th>
                                    <th scope="col">Brand</th>
                                    <th scope="col">Video Link</th>
                                    <th scope="col">Video</th>                                    
                                    <th scope="col">Description</th>  
                                    <th scope="col">Short  Description</th> 
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>                                       
                                        <td><?php echo e($banner->name); ?><br/>
                                        <small class="my-2">ID= <?php echo e($banner->id); ?></small><br/>
                                        <small class="my-2">Slug= <?php echo e($banner->slug); ?></small>
                                        </td>
                                        <td>
                                            <?php if($banner->brand): ?>
                                            <?php echo e($banner->brand->name); ?>

                                            <?php else: ?> 
                                            No Brand Silected
                                            <?php endif; ?>
                                        </td>
                                        <td  width="300px"><?php echo e($banner->video_url); ?></td>
                                        <td><?php echo e($banner->video); ?></td>                                        
                                        <td width="300px"><?php echo e($banner->description); ?></td>
                                        <td width="300px"><?php echo e($banner->other_description); ?></td>
                                        <td>
                                           
                                        </td>
                                        <td>
                                            <div class="editDelet">
                                            <a href="<?php echo e(url('admin/banner/' . $banner->id . '/edit')); ?>"
                                                class="btn btn-success">Edit</a>
                                                <form action="<?php echo e(url('admin/banner/'.$banner->id.'',  )); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
            
                                                        <input type="submit" class="btn btn-danger" value="Delete" />
                                                    
                                                </div>
                                                  </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                        <div class="col-12 my-3">
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views\admin\banners\index.blade.php ENDPATH**/ ?>