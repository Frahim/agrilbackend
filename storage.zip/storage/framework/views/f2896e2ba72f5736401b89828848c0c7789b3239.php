

<?php $__env->startSection('content'); ?>
<div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between flex-wrap">
                <div class="d-flex align-items-end flex-wrap">
                  <div class="me-md-3 me-xl-5">
                    <?php if(session('message')): ?>
                    <h2  class="alert alert-success" role="alert"><?php echo e((session('message') )); ?>,</h2>
                    <?php endif; ?>
                    
                  </div>
                  
                </div>
                
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>