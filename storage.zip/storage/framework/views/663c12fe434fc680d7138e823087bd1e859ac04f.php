<div>

    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Brand Delete</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form wire:submit.prevent='destroyBrand'>
                    <div class="modal-body">
                        <h4>Are you Sure you want to delete the Brand</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>





    <div class="row">
        <?php if(session('message')): ?>
            <div class="col-md-10 alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center py-2">
                    <h3 class="m-0 align-middle">Brands</h3>
                    <a href="<?php echo e(url('admin/brand/create')); ?>" class="btn btn-primary btn-sm float-end">Add Brand</a>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Id</th>
                                <th scope="col">Name</th>
                                <th scope="col">Logo</th>
                                <th scope="col">Description</th>
                                <th scope="col">Satus</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($brand->id); ?></td>
                                    <td><?php echo e($brand->name); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('/uploads/brand/' . $brand->logo)); ?>" width="60px"
                                            height="60px" />
                                    </td>
                                    <td><?php echo e($brand->description); ?></td>
                                    <td><?php echo e($brand->status == '1' ? 'Hidden' : 'Visible'); ?></td>
                                    <td>
                                        <div class="editDelet">
                                        <a href="<?php echo e(url('admin/brand/' . $brand->id . '/edit')); ?>"
                                            class="btn btn-success">Edit</a>
                                        
                                      <form action="<?php echo e(url('admin/brand/'.$brand->id.'',  )); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>                                       
                                            <input type="submit" class="btn btn-danger " value="Delete" />
                                        
                                    </div>
                                      </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <div class="col-12 my-3">
                        <?php echo e($brands->links()); ?>

                    </div>
                </div>
            </div>
           
        </div>
    </div>
</div>
<?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views\livewire\admin\brand\index.blade.php ENDPATH**/ ?>