

<?php $__env->startSection('content'); ?>
<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.brand.index', [])->html();
} elseif ($_instance->childHasBeenRendered('24IK3T0')) {
    $componentId = $_instance->getRenderedChildComponentId('24IK3T0');
    $componentTag = $_instance->getRenderedChildComponentTagName('24IK3T0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('24IK3T0');
} else {
    $response = \Livewire\Livewire::mount('admin.brand.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('24IK3T0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\agril backup\agrilbackend\resources\views/admin/brand/index.blade.php ENDPATH**/ ?>