


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between py-3">
                    <h3 class="mb-0">Add Products</h3>
                    <a href="<?php echo e(url('admin/products')); ?>" class="btn btn-primary text-white float-end">Back</a>
                </div>
                <!-- Nav tabs -->
                <ul class="nav nav-tabs">
                    <li><a class="active" href="#info-pills" data-toggle="tab">Product Info</a></li>
                    <li class=""><a href="#variation-pills" data-toggle="tab">Description</a></li>
                    <li class=""><a href="#price-pills" data-toggle="tab">Price</a></li>            
                    <li class=""><a href="#seo-pills" data-toggle="tab">SEO</a></li>
                </ul>
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-warning mb-3">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><?php echo e($error); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(url('admin/products')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="tab-content">
                            <div class="tab-pane fade in active show" id="info-pills">
                                <div class="my-3 row">
                                    <div class="col-sm-12 col-md-4">
                                        <label class="col-12">Product Name</label>
                                        <input type="text" name="name" class="form-control col-12" />
                                    </div>
                                    <div class="col-sm-12 col-md-4">
                                        <label>Product Slug</label>
                                        <input type="text" name="slug" class="form-control col-12" />
                                    </div>
                                    <div class="col-sm-12 col-md-4">
                                        <label>Product Type</label>
                                        <input type="text" name="type" class="form-control col-12" />
                                    </div>
                                </div>

                                <div class="my-3 row">
                                    <div class="col-sm-12 col-md-6">
                                        <label class="col-12 me-3">Select Brand</label>
                                        <select name="brand_id" class="form-conrol p-2">
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <label class="col-12 me-3">Select Category</label>
                                        <select class="category col-12 border border-primary" name="category[]"
                                            multiple="multiple">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                </div>
                                <div class="my-3">
                                    <label class="col-sm-2 col-form-label">Product Image</label>
                                    <div class="col-sm-10">
                                        <div class="input-group">
                                            <input type="file" name="pf_image" required class="form-control">

                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="tab-pane fade in" id="variation-pills">
                                <div class="row">
                                    <div class="col-sm-12 col-md-12 my-3 ">
                                        <label> Product Description</label>
                                        <textarea rows="5" type="textarea" name="description" placeholder="Enter text ..."></textarea>
                                    </div>

                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Disease Resistance/Tolerance</label>
                                        <textarea name="disease" class="form-control" placeholder="Enter text ..."></textarea>
                                    </div>

                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Variety</label>
                                        <textarea rows="5" type="textarea" name="variety" class="form-control"></textarea>
                                    </div>
                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Sorting</label>
                                        <textarea rows="5" type="textarea" name="sorting" class="form-control"></textarea>
                                    </div>
                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Pod</label>
                                        <textarea rows="5" type="textarea" name="pod" class="form-control"></textarea>
                                    </div>
                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Plant</label>
                                        <textarea rows="5" type="textarea" name="plant" class="form-control"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade in" id="price-pills">
                                <div class="my-3 row">
                                    <div class="col-sm-12 col-md-4">
                                        <label> Product Quantity</label>
                                        <input type="text" name="quantity" class="form-control" />
                                    </div>
                                    <div class="col-sm-12 col-md-4">
                                        <label> Product Regular Price</label>
                                        <input type="text" name="orginal_price" class="form-control" />
                                    </div>
                                    <div class="col-sm-12 col-md-4">
                                        <label> Product Selling Price</label>
                                        <input type="text" name="selling_price" class="form-control" />
                                    </div>

                                </div>

                            </div>
                           
                            <div class="tab-pane fade in" id="seo-pills">
                                <div class="my-3">
                                    <label> Product Meta Title</label>
                                    <input type="text" name="meta_title" class="form-control" />
                                </div>
                                <div class="my-3">
                                    <label> Product Meta Keyword</label>
                                    <input type="text" name="meta_keyword" class="form-control" />
                                </div>
                                <div class="my-3">
                                    <label> Product Meta Description</label>
                                    <input type="text" name="meta_description" class="form-control" />
                                </div>
                            </div>
                        </div>
                        <div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views\admin\products\create.blade.php ENDPATH**/ ?>