

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between py-3">
                <h3 class="mb-0">Add New Post</h3>
                <a href="<?php echo e(url('admin/posts/create')); ?>" class="btn btn-primary text-white float-end">Back</a>
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-warning mb-3">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
                <form action="<?php echo e(url('admin/posts')); ?>"  method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="col-sm-12 col-md-6">
                            <label class="col-form-label">Post Name</label>
                            <div class="col-sm-10">
                                <input type="text" name="title" class="form-control">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>    
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label class="col-form-label">Post Slug</label>
                            <div class="col-sm-10">
                                <input type="text" name="slug" class="form-control">
                                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>    
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>  
                    <div class="row mb-3">
                        <div class="col-sm-12 col-md-12">
                        <label class="col-form-label">Content</label>
                        <div class="col-sm-12">
                            <textarea rows="5" name="content" class="form-control summernote"></textarea>
                        </div>
                    </div>
                   
                    </div>  
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Featured Iamge</label>
                        <div class="col-sm-10">
                            <div class="input-group">
                                <input type="file" name="featured_image" class="form-control">
                                <label class="input-group-text" for="inputGroupFile02">Upload</label>
                            </div>
                        </div>
                    </div>                  
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">SEO Title</label>
                        <div class="col-sm-10">
                            <div class="input-group">
                                <input type="text" name="seo_title" class="form-control">                               
                            </div>
                        </div>
                    </div> 
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">SEO Description</label>
                        <div class="col-sm-10">
                            <div class="input-group">
                                <input type="text" name="seo_description" class="form-control">                               
                            </div>
                        </div>
                    </div>                    
                    <div class="row mb-3">
                    <div class="col-12 ">
                        <button type="submit" class="btn btn-primary text-white">Submit</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>