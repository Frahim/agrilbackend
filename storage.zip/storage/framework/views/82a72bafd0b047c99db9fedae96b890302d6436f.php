

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between py-3">
                    <h3 class="mb-0">Edit Products</h3>
                    <a href="<?php echo e(url('admin/products')); ?>" class="btn btn-primary text-white float-end">Back</a>
                </div>
                <!-- Nav tabs -->
                <ul class="nav nav-tabs">
                    <li><a class="active" href="#info-pills" data-toggle="tab">Product Info</a></li>                     
                    <li class=""><a href="#variation-pills" data-toggle="tab">Description</a></li>   
                    <li class=""><a href="#price-pills" data-toggle="tab">Price</a></li>
                    <li class=""><a href="#seo-pills" data-toggle="tab">SEO</a></li>
                </ul>

                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-warning mb-3">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><?php echo e($error); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(url('admin/products/'. $product->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                     

                        <div class="tab-content">
                            <div class="tab-pane fade in active show" id="info-pills">
                                <div class="my-3 row">                                   
                                    <div class="col-sm-12 col-md-4">
                                        <label class="col-12">Product Name</label>
                                        <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control col-12" />
                                    </div>
                                    <div class="col-sm-12 col-md-4">
                                        <label>Product Slug</label>
                                        <input type="text" name="slug" value="<?php echo e($product->slug); ?>" class="form-control col-12" />
                                    </div>
                                    <div class="col-sm-12 col-md-4">
                                        <label>Product Type</label>
                                        <input type="text" name="type" value="<?php echo e($product->type); ?>" class="form-control col-12" />
                                    </div>
                                </div>

                                <div class="my-3 row"> 
                                    <div class="col-sm-12 col-md-6">
                                    <label class="col-12 me-3">Select Brand</label>
                                    <select name="brand_id" class="form-conrol p-2">
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <label class="col-12 me-3">Select Category</label>
                                        <select class="category col-12 border border-primary" name="category[]" multiple="multiple">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php if(in_array($category->id, $selectedCategories)): ?> selected <?php endif; ?>>
                                                    <?php echo e($category->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="my-3 col-12">
                                        <label class="col-sm-2 col-form-label">Product Image</label>
                                        <div class="col-sm-10">
                                            <div class="input-group">
                                                <input type="file" name="pf_image" class="form-control"><br/>
                                                
                                                <img src="<?php echo e(asset($product->pf_image)); ?>" width="60px"
                                                height="60px">
                                            </div>
                                        </div>
                                    </div> 
                                </div>
                                                                                           
                                
                            </div>
                            
                            <div class="tab-pane fade in" id="variation-pills">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label> Product Description</label>
                                        <textarea rows="5" type="textarea" name="description" class="form-control" ><?php echo e($product->description); ?></textarea>
                                    </div>
                                    
                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Disease Resistance/Tolerance</label>
                                        <textarea rows="5" type="textarea" name="disease" class="form-control" ><?php echo e($product->disease); ?></textarea>
                                    </div>

                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Variety</label>
                                        <textarea rows="5" type="textarea" name="variety" class="form-control" ><?php echo e($product->variety); ?></textarea>
                                    </div>
                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Sorting</label>
                                        <textarea rows="5" type="textarea" name="sorting" class="form-control" ><?php echo e($product->sorting); ?></textarea>
                                    </div>
                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Pod</label>
                                        <textarea rows="5" type="textarea" name="pod" class="form-control" ><?php echo e($product->pod); ?></textarea>
                                    </div>
                                    <div class="col-sm-12 col-md-6 my-3 ">
                                        <label>Plant</label>
                                        <textarea rows="5" type="textarea" name="plant" class="form-control" ><?php echo e($product->plant); ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade in" id="price-pills">
                                <div class="my-3 row"> 
                                    <div class="col-sm-12 col-md-4">
                                        <label> Product Quantity</label>
                                        <input type="text" name="quantity" value="<?php echo e($product->quantity); ?>" class="form-control" />
                                    </div>
                                    <div class="col-sm-12 col-md-4">
                                        <label> Product Regular Price</label>
                                        <input type="text" name="orginal_price" value="<?php echo e($product->orginal_price); ?>" class="form-control" />
                                    </div>
                                    <div class="col-sm-12 col-md-4">
                                        <label> Product Selling Price</label>
                                        <input type="text" name="selling_price" value="<?php echo e($product->selling_price); ?>" class="form-control" />
                                    </div>
                                    
                                </div>
                                
                            </div>
                          
                            <div class="tab-pane fade in" id="seo-pills">
                                <div class="my-3">
                                    <label> Product Meta Title</label>
                                    <input type="text" name="meta_title" value="<?php echo e($product->meta_title); ?>" class="form-control" />
                                </div>
                                <div class="my-3">
                                    <label> Product Meta Keyword</label>
                                    <input type="text" name="meta_keyword" value="<?php echo e($product->meta_keyword); ?>" class="form-control" />
                                </div>
                                <div class="my-3">
                                    <label> Product Meta Description</label>
                                    <input type="text" name="meta_description" value="<?php echo e($product->meta_description); ?>" class="form-control" />
                                </div>
                            </div>
                        </div>
                        <div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views\admin\products\edit.blade.php ENDPATH**/ ?>