

<?php $__env->startSection('content'); ?>
<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.brand.index', [])->html();
} elseif ($_instance->childHasBeenRendered('QrrJSsc')) {
    $componentId = $_instance->getRenderedChildComponentId('QrrJSsc');
    $componentTag = $_instance->getRenderedChildComponentTagName('QrrJSsc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QrrJSsc');
} else {
    $response = \Livewire\Livewire::mount('admin.brand.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('QrrJSsc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views/admin/brand/index.blade.php ENDPATH**/ ?>