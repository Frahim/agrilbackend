<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between py-3">
                <h3 class="mb-0">All Category</h3>
                <a href="<?php echo e(url('admin/category/create')); ?>" class="btn btn-primary text-white float-end">Add Category</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    

                    <div class="col-12 my-3">
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views\livewire\admin\category\index.blade.php ENDPATH**/ ?>