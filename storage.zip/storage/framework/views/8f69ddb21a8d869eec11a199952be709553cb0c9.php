

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(session('message')): ?>
            <div class="col-md-10 alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center py-2">
                    <h3 class="m-0 align-middle">Products</h3>
                    <a href="<?php echo e(url('admin/product/create')); ?>" class="btn btn-primary btn-sm float-end">Add Product</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table  table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Brand</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Price</th>                                    
                                    <th scope="col">Quantity</th>
                                    <th scope="col"><small>Disease Resistance/<br/>Tolerance</small></th>
                                    <th scope="col">Variety</th>
                                    <th scope="col">Sorting</th>
                                    <th scope="col">Pod</th>
                                    <th scope="col">plant</th>
                                    <th scope="col">Image</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->name); ?><br /><small><?php echo e($product->id); ?></small><br /><small><?php echo e($product->slug); ?></small>
                                        </td>
                                        <td>
                                            <?php if($product->brand): ?>
                                                <?php echo e($product->brand->name); ?>

                                            <?php else: ?>
                                                No Brand Silected
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($product->category): ?>
                                                <?php echo e($product->category); ?>

                                            <?php else: ?>
                                                No Category Silected
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($product->description); ?></td>
                                        <td>
                                            Orginal Price: <?php echo e($product->orginal_price); ?>

                                            <br />
                                            Selling Price: <?php echo e($product->selling_price); ?>

                                        </td>
                                        
                                        <td><?php echo e($product->quantity); ?></td>

                                        <td><?php echo e($product->disease); ?></td>
                                        <td><?php echo e($product->variety); ?></td>
                                        <td><?php echo e($product->sorting); ?></td>
                                        <td><?php echo e($product->pod); ?></td>
                                        <td><?php echo e($product->plant); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($product->pf_image)); ?>" width="60px"
                                                    height="60px">
                                            

                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('admin/products/' . $product->id . '/edit')); ?>"
                                                class="btn btn-success">Edit</a>
                                            <a href="<?php echo e(url('admin/products/' . $product->id . '/delete')); ?>"                                                
                                                class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                        <div class="col-12 my-3">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views/admin/products/index.blade.php ENDPATH**/ ?>