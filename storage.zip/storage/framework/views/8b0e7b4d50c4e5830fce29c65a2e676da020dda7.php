

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between py-3">
                <h3 class="mb-0">All Category</h3>
                <a href="<?php echo e(url('admin/category/create')); ?>" class="btn btn-primary text-white float-end">Add Category</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table  table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Id</th>
                                <th scope="col">Name</th>
                                <th scope="col">Slug</th>
                                <th scope="col">Description</th>
                                <th scope="col">Image</th>
                                <th scope="col">Meta Title</th>
                                <th scope="col">Meta Keyword</th>  
                                <th scope="col">Meta Description</th> 
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($category->id); ?></td>
                                    <td><?php echo e($category->name); ?></td>                                    
                                    <td><?php echo e($category->slug); ?></td>
                                    <td><?php echo e($category->description); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('/uploads/category/' . $category->cat_image)); ?>" width="60px"
                                            height="60px" />
                                    </td>
                                    <td><?php echo e($category->meta_title); ?></td>
                                    <td><?php echo e($category->meta_keyword); ?></td>
                                    <td><?php echo e($category->meta_description); ?></td>
                                   
                                    <td>
                                        <a href="<?php echo e(url('admin/category/' . $category->id . '/edit')); ?>"
                                            class="btn btn-success">Edit</a>
                                        <a href="#" wire.click="deleteproduct(<?php echo e($category->id); ?>)"
                                            data-bs-toggle="modal" data-bs-target="#deleteModal"
                                            class="btn btn-danger">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <div class="col-12 my-3">
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Client\Agril\aggrilfood\aggrilfood\new-LVadmin\resources\views\admin\category\index.blade.php ENDPATH**/ ?>