

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(session('message')): ?>
            <div class="col-md-10 alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center py-2">
                    <h3 class="m-0 align-middle">All Socialmedia Item</h3>
                    <a href="<?php echo e(url('admin/socialmedia/create')); ?>" class="btn btn-primary btn-sm float-end">Add New Item</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table  table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">List Of Item</th>
                                    <th scope="col"> Settings</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $socialmedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <h2 class="mb-0"><?php echo e($social->smname); ?></h2><br />
                                            <small class="my-2">ID= <?php echo e($social->id); ?></small><br />
                                           
                                        </td>
                                        <td>
                                            <div class="editDelet">
                                                <a href="<?php echo e(url('admin/socialmedia/' . $social->id . '/edit')); ?>"
                                                    class="btn btn-success">Edit</a>
                                                <form action="<?php echo e(url('admin/socialmedia/' . $social->id . '')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <input type="submit" class="btn btn-danger" value="Delete" />
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                        <div class="col-12 my-3">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\agril backup\agrilbackend\resources\views/admin/socialmedia/index.blade.php ENDPATH**/ ?>